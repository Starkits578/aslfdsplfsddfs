# stock-gen-bot
Discord stock generator bot
