const Discord = require("discord.js");

module.exports = {
    name: "satınal",
    description: "VIP aboneliği satın almak için bilgi alın.",
    execute(message, args) {
        const embed = new Discord.MessageEmbed()
            .setColor("#0099ff")
            .setTitle("ZALORANT ABONELİK FİYATI")
            .setDescription(
                "Satın almak için Ticket Açabilirsin:",
            )
            .addFields(
                {
                    name: "Aylık Abonelik",
                    value: "[Aylık Abonelik Satın Al](TİCKET AÇ)",
                    inline: true,
                },
                {
                    name: "Haftalık Abonelik",
                    value: "[Haftalık Abonelik Satın Al](TİCKET AÇ)",
                    inline: true,
                },
            );

        message.channel.send({ embeds: [embed] });
    },
};
